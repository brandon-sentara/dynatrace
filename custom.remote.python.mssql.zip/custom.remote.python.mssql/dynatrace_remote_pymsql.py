from ruxit.api.data import PluginMeasurement, PluginProperty, PluginStateMetric
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import ConfigException, NothingToReportException
from ruxit.api.data import MEAttribute

# generic
import os
import platform
import random
from collections import namedtuple, defaultdict
import time
from time import ctime

import logging
log = logging.getLogger(__name__)

# drivers
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
import pymssql
import json


            #host='localhost', # TEM
            #user='labuser',
            #password='labpass'

class MssqlPlugin(RemoteBasePlugin):
    def initialize(self, **kwargs):
        config = kwargs['config']

        if not config['host']:
            raise ConfigException("Host field is empty")
        if not config['user']:
            raise ConfigException("User field is empty")
        if not config["dbname"]:
            raise ConfigException("Database name field is empty")
        #if not config['password']:
            #raise ConfigException("Password field is empty")

        self.timeseries = kwargs['json_config']['metrics']

        # TODO - reconnect if necessary
        self.conn = pymssql.connect(
            host=config.get('host'),
            user=config.get('user'),
            password=config.get('password'),
            database=config.get("dbname")
            #server=self.server_address,
        )  
        self.cursor = self.conn.cursor()


    def query(self, **kwargs):
        group_name = "MSSQL"
        topology_group = self.topology_builder.create_group(group_name, group_name)
        
        device_name = "MSSQL DB"
        topology_device = topology_group.create_device(device_name, device_name)

        # TODO per_second metrics?
        self.report_metrics(topology_device)


    def report_metrics(self, custom_device):
        for metric in self.timeseries:
            source = metric.get('source')
            if not source:
                continue

            self.report_counter_value(
                custom_device,
                metric.get('timeseries').get('key'),
                source.get('counter_name'),
                source.get('instance_name')
            )

        self.report_worker_counter(custom_device)


    def report_counter_value(self, custom_device, metric_key, counter_name, instance_name):
        # MSSQL internal metric types:
        PERF_COUNTER_LARGE_RAWCOUNT = 65792
        PERF_COUNTER_COUNTER        = 272696320
        PERF_AVERAGE_BULK_ABSOLUTE  = 537003264

        PERF_COUNTER_BULK_COUNT     = 272696576
        PERF_AVERAGE_BULK_RELATIVE  = 1073874176
        PERF_LARGE_RAW_BASE         = 1073939712

        ABSOLUTE_COUNTERS = [PERF_COUNTER_LARGE_RAWCOUNT, PERF_COUNTER_COUNTER, PERF_AVERAGE_BULK_ABSOLUTE]
        RELATIVE_COUNTERS = [PERF_COUNTER_BULK_COUNT, PERF_AVERAGE_BULK_RELATIVE, PERF_LARGE_RAW_BASE]
        
        # cntr_value
        total_filter = f"AND instance_name = '{instance_name}'" if instance_name else ""

        query = f"""
        SELECT instance_name,cntr_value,cntr_type from sys.dm_os_performance_counters
        WHERE counter_name = '{counter_name}'
        {total_filter}
        ;"""

        self.cursor.execute(query)
        row = self.cursor.fetchone()

        if row:
            counter_type = row[2]
            counter_type_human = "unknown"

            counter_value = row[1]

            if counter_type in ABSOLUTE_COUNTERS:
                counter_type_human = "absolute" # MSSQL "instant"
                custom_device.absolute(metric_key, counter_value)

            elif counter_type in RELATIVE_COUNTERS:
                counter_type_human = "relative" # MSSQL "cumulative"
                custom_device.relative(metric_key, counter_value)

            #print (f"{counter_name:35} | {row[0].strip():^15} | {counter_value:10} | {counter_type_human}({counter_type})")
        else:
            raise RuntimeError(f"{counter_name:35} MISSING")


    def report_worker_counter(self, custom_device):
        q = "SELECT state from sys.dm_os_workers;"
        self.cursor.execute(q)
        ble = self.cursor.fetchall()
        from collections import Counter
        c = Counter(ble)
        
        total = sum(c.values())
        running = c[("RUNNING",)]

        custom_device.absolute("worker_threads_allocated", total)
        custom_device.absolute("worker_threads_active", running)
        #print(f"Worker threads allocated [custom] | {total}")
        #print(f"Worker threads active [custom] | {running} ")

        