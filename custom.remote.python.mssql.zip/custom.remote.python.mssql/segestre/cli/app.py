import argparse
from segestre.storage import Storage

from segestre import Segestre
from segestre.cli.table import dict_to_table, print_table
from segestre.cli.builder import PluginBuilder


class CommandLineApp:
    def __init__(self, plugin: Segestre):
        self.plugin = plugin

    def run(self) -> None:
        def settings_command(limit: int):
            config_as_table = dict_to_table(
                self.plugin.settings, headers=["Setting", "Value"]
            )
            print_table(config_as_table)

        def collect_command(executions: int, limit: int):
            for _ in range(executions):
                self.plugin.collect()
                self.plugin.calculator.calculate(evaluation_limit=5)

            storage_as_table = dict_to_table(
                self.plugin.storage, headers=["Metric", "Value"], limit=limit
            )
            print_table(storage_as_table)

            for d in self.plugin.storage:
                for m in self.plugin.storage[d][Storage.default_source]:
                    print(f"{m}: {self.plugin.storage[d][m]}")

        def build_command(path: str):
            builder = PluginBuilder(self.plugin.settings)
            dump = builder.build()
            #print(dump)
            if path:
                builder.save(dump, path)

        parser = argparse.ArgumentParser()
        parser.add_argument("command")
        parser.add_argument("-n", "--executions-number", type=int, default=1)
        parser.add_argument("-l", "--row-limit", type=int, default=20)
        parser.add_argument("-p", "--path", type=str, default="")
        args = parser.parse_args()

        if args.command in "settings" or args.command in "config":
            settings_command(args.row_limit)
        elif args.command in "collect":
            collect_command(args.executions_number, args.row_limit)
        elif args.command in "build":
            build_command(args.path)
        else:
            print("Unknown command")
