import logging

from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.exceptions import AuthException, ConfigException

from segestre.calculator import Calculator
from segestre.storage import Storage, Source


logger = logging.getLogger(__name__)


class Segestre(RemoteBasePlugin):
    def __init__(self, *args, settings=None, **kwargs):
        self.settings = settings
        self.storage = Storage()
        self.availability = 0
        self.calculator = Calculator(self.settings, self.storage)
        self.query_counter = 0
        super().__init__(*args, **kwargs)

    def collect(self) -> None:
        raise NotImplementedError()

    def build_group_and_device_name(self) -> str:
        raise NotImplementedError()

    def build_dimension_key(self, **dimensions) -> frozenset:
        """
        Returns a hashable frozenset of tuples per each dimension name and value.
        This key should be used for storing multiple dimensions per metric.
        """
        return frozenset({(k, v) for k, v in dimensions.items()})

    def query(self, **kwargs):
        logger.info("Executing query()")

        # Config sent to us from the tenant
        self.config = kwargs["config"]

        # Collect gui connection params
        self.collect_gui_properties()

        # Initialize topology
        self.initialize_topology()

        try:
            self.collect()
            self.availability = 100
        except Exception as e:
            if self.query_counter:
                # If that's not the first launch of plugin
                self.availability = 0
            else:
                raise ConfigException(f"Exception when trying to collect first data: {e}")

        try:
            self.device.absolute("AvailabilityPercent", self.availability, dimensions={})
            self.calculator.calculate(evaluation_limit=20)
            self.report()
        except Exception as e:
            logger.exception(f"Exception: {e}")
            raise e

        self.query_counter += 1
        logger.info(f"Executed query() method {self.query_counter} times so far")

    def report(self) -> None:
        logger.info("Reporting metrics")
        reported_metrics_counter = 0

        # For each metric
        for key, m in self.settings["metrics"].items():
            requested_dimensions = m["dimensions"]

            # For each combination of dimensions
            for d in self.storage:
                # Check if this dimension combination was reequested to be reported by metric
                if {e[0] for e in d} != set(requested_dimensions):
                    # Ignore this dimension combination entirely if is is not requested for the metric
                    continue

                # Form a report-compatible dimension dictionary with values
                dimensions = {str(k): str(v) for k, v in d}

                # For each unit
                if "units" in m:
                    for u in m["units"]:
                        name = f"{key}{u['unit']}"

                        # If metric should be collected (as configured in UI)
                        if self.config[name] is True:
                            logger.info(f"Reporting {name} within '{dimensions}'")

                            metric = self.storage[d][Storage.default_source][name]
                            value = metric.latest

                            if u["type"] == "absolute":
                                self.device.absolute(name, float(value), dimensions)
                            elif u["type"] == "relative":
                                self.device.relative(name, float(value), dimensions)
                            elif u["type"] == "per_second":
                                self.device.per_second(name, float(value), dimensions)
                            else:
                                raise ConfigException(f"Wrong unit type '{u['unit']}' in metric '{key}")

                            reported_metrics_counter += 1

                elif "states" in m:
                    if self.config[key] is True:
                        logger.info(f"Reporting {key} within '{dimensions}'")

                        state_value = self.storage[d][Storage.default_source][key].latest
                        state_name = [s["name"] for s in m["states"] if s["value"] == state_value]

                        if state_name:
                            self.device.state_metric(key, state_name[0], dimensions)
                        else:
                            raise ConfigException(f"No matching state name for state value '{state_value}' of metric '{key}'")

                        reported_metrics_counter += 1

        logger.info(f"Reported {reported_metrics_counter} metrics in this call")

    def store(self, source, dimension_keys, mapping, ignore_dimension_values=False):
        # Build dimensions key by looking up dimension values.
        # I.e. if current result contains "tablespace" dimension in it, then
        # get the value of the "tablespace" key to report the result to the 
        # proper dimension when sending it to the Dynatrace tenant.
        dimension_key = self.build_dimension_key(
            **{d: mapping[d] for d in dimension_keys}
        )

        # Store values in storage but ignore values that represent
        # dimensions if requested to do so by argument.
        items_to_push = (
            filter(lambda c: c[0] not in dimension_keys, mapping.items())
            if ignore_dimension_values else mapping.items()
        )

        for c, v in items_to_push:
            if source not in self.storage[dimension_key]:
                # Special case for unexisting source. We can't use defaultdict
                # here because Dimension's __getitem__ method is overridden
                # to support metric source guessing mechanism.
                self.storage[dimension_key][source] = Source()
            self.storage[dimension_key][source][c].latest = v

    def collect_gui_properties(self):
        logger.info("Collecting GUI properties")
        # Extract from parameters set by tenant in GUI
        for key, p in self.settings["properties"].items():

            if p.get("required", False):
                if key not in self.config:
                    raise ConfigException(f"Property {key} is not optional and is missing in endpoint configuration")
                elif p["type"] in ("String", "Password", "Textarea", "Dropdown") and not self.config[key]:
                    raise ConfigException(f"Property {key} is not optional and cannot be empty in endpoint configuration")

            self.settings["connection"][key] = self.config[key]
            logger.info(f"Collected {key} property from GUI: {self.settings['connection'][key]}")

    def initialize_topology(self):
        logger.info("Initializing topology")

        group_name, device_name = self.build_group_and_device_name()
        logger.info(f"Group name: {group_name}")
        logger.info(f"Device name: {device_name}")

        self.group = self.topology_builder.create_group(group_name, group_name)
        self.device = self.group.create_device(device_name, device_name)
