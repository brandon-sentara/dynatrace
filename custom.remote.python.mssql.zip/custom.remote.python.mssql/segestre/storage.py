from collections import defaultdict
from numbers import Number
from typing import Any, Dict, List

from segestre.exceptions import NotEnoughValues


class Storage(defaultdict):
    """
    Metric storage structure

    Hierarchy:
        1. storage is a defaultdict of dimensions
            with lambda:
            where when <dimension> is unknown, we create new dict of sources for it
        2. dimension is a dict of sources
            with lambda:
            where when "source" is unknown, we create new empty dict of metrics for it
        3. source is a defaultdict of metrics
            with lambda:
            where when "metric" is unknown, we create new empty list of values for it
        4. metric is a list of values

    Getting last value of metric in dimension:
        storage[<dimension>]["source"]["metric"][0]

    Source is the name of the query from which the value is obtained or "calculated"
    with latter representing all computed values, not originally available in the
    query.

    Dimension is a frozen set of tuple pairs of ("subdimension_name", value)
        <dimension> = frozenset({("member", 0), ("bp_name", "duo")})
    """

    # How many values to keep per source-metric-dimension combination
    storage_limit = 4
    default_source = "calculated"

    def __init__(self, *args):
        """
        Initialize this class as defaultdict because for each new 'dimension' we want
        to initilize empty defaultdict of sources and metrics in them.
        """

        # Each single metric in storage is represented by a dictionary where dimension is a key.
        # Dimension key is represented as a hashable frozenset of (key, value) tuples each representing
        # a dimension name and its value.
        # To obtain list of values of metric 'int_commits' from storage you'd use:
        #   storage[frozenset({("member", 0)})]["mon_get_database"]["int_commits"]

        # Moreover, default value for each dimension is a history queue of values for this particular
        # metric in this particular dimension. That's why default value for default dict is list.

        super().__init__(
            # When unknown dimension is requested, initialize it as a defaultdict of sources
            lambda: Dimension()
        )


class Dimension(dict):
    """
    Dictionary of sources

    Dimension is a context for evaluating the formula expression for each metric.
    """

    def __init__(self):
        super().__init__()
        self[Storage.default_source] = Source()

    def __getattr__(self, attr):
        """
        Return requested source (convenience method)
        """
        return self[attr]

    def __getitem__(self, key):
        """
        Returns requested source from dimension but supports direct metric invokation from default source as well

        When used in metric formula like this
            mon_get_database.total_app_commits
        will return
            "mon_get_database" source
            so that you can extract latest value of "total_app_commits" metric from it as an attribute

        When used in metric formula like this
            TotalApplicationCommits
        will return
            latest value of calculated metric "TotalApplicationCommits" from "calculated" source
        """

        if key in self:
            # e.g. mon_get_database
            return dict.__getitem__(self, key)
        elif key == "delta":
            # e.g. delta("TotalAppCommits")
            return dict.__getitem__(self, Storage.default_source)
        else:
            # e.g. TotalApplicationCommits
            return dict.__getitem__(self, Storage.default_source).__getattr__(key)


class Source(defaultdict):
    """
    Dictionary of metrics
    """

    def __init__(self, *args):
        super().__init__(
            *(
                args
                or (
                    # For each unknown metric in source initialize a Metric object
                    lambda: Metric(),
                )
            )
        )

    def __call__(self, metric):
        """
        Return delta between two latest values of metric in the source

        When used in metric formula like this:
            delta('TotalApplicationsCount')
        returns
            latest value of "TotalApplicationsCount" minus its previous value
        """
        return self[metric].delta

    def __getattr__(self, metric):
        """
        Return latest value of metric in the source

        When used in metric formula like this:
            mon_get_database.total_app_commits
        returns
            latest value of "total_app_commits" metric
        """
        return self[metric].latest


class Metric:
    def __init__(self):
        self._history = list()

    @property
    def history(self) -> List:
        """
        Return history of values for the metric
        """
        return self._history

    @property
    def latest(self) -> Any:
        """
        Return latest value for the metric
        """
        if len(self.history):
            return self.history[0]
        else:
            raise NameError("No value available yet for metric")

    @latest.setter
    def latest(self, value) -> None:
        """
        Set latest value for the metri
        """
        self.push(value)

    @property
    def delta(self) -> Any:
        """
        Return the delta between two latest values of the metric
        """
        if len(self.history) > 1:
            return self.history[0] - self.history[1]
        else:
            raise NotEnoughValues("Not enough value in history for delta")

    def push(self, value) -> None:
        """
        Save new value as latest for the metric.

        Same as setting the 'latest' property.
        """

        # If storage limit is exceeded for this metric, remove oldest value
        if len(self.history) > Storage.storage_limit:
            self.history.pop()

        # Save latest value
        self.history.insert(0, value)

    def __str__(self) -> str:
        return str(self.history)
