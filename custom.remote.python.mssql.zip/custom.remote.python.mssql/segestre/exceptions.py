class NotEnoughValues(Exception):
    pass
